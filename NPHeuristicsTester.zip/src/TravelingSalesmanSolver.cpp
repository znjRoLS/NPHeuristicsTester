#include "TravelingSalesmanSolver.h"

TravelingSalesmanSolver::TravelingSalesmanSolver(string name)
{
    this->name = name;
}

TravelingSalesmanSolver::~TravelingSalesmanSolver()
{

}
