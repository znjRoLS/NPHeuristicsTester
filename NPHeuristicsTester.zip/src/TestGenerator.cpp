#include "TestGenerator.h"

TestGenerator::TestGenerator(string name)
{
    this->name = name;
}

TestGenerator::~TestGenerator()
{

}
